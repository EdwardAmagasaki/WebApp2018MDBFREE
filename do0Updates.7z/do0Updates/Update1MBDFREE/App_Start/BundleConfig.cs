﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Optimization;

namespace do0
{
    public class BundleConfig
    {
        // Para obter mais informações sobre o agrupamento, visite https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                "~/Scripts/jquery.unobtrusive*",
                "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/knockout").Include(
                "~/Scripts/knockout-{version}.js",
                "~/Scripts/knockout.validation.js"));

            bundles.Add(new ScriptBundle("~/bundles/app").Include(
                "~/Scripts/sammy-{version}.js",
                "~/Scripts/app/common.js",
                "~/Scripts/app/app.datamodel.js",
                "~/Scripts/app/app.viewmodel.js",
                "~/Scripts/app/home.viewmodel.js",
                "~/Scripts/app/_run.js"));

            // Use a versão em desenvolvimento do Modernizr para desenvolver e aprender com ela. Após isso, quando você estiver
            // pronto para a produção, utilize a ferramenta de build em https://modernizr.com para escolher somente os testes que precisa.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/Scripts/bootstrap.js",
                "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                 "~/Content/bootstrap.css",
                 "~/Content/Site.css"));

            // MDBootstrap 4 Free JQuery - 10/01/2018
            bundles.Add(new ScriptBundle("~/bundles/MBDJS").Include(
                "~/Content/MDBFree/js/jquery-3.2.1.min.js",
                "~/Content/MDBFree/js/popper.min.js",
                "~/Content/MDBFree/js/bootstrap.js",
                "~/Scripts/respond.js",
                "~/Content/MDBFree/js/mdb.js"));

               bundles.Add(new StyleBundle("~/Content/MDBCSS").Include(
                "~/Content/MDBFree/css/bootstrap.css",
                 "~/Content/MDBFree/css/mdb.css",
                 "~/Content/MDBFree/css/style.css",
                 "~/Content/MDBFree/css/font-awesome.css"));
        }
    }
}
